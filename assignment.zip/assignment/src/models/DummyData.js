const mongoose = require("mongoose");

const DummyDataSchema = new mongoose.Schema(
  {
    title: String,
    description: String,
    status: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model("DummyData", DummyDataSchema);