const rolePermissions = {
  Admin: [
    "user:read",
    "user:assign-role",
    "manager:read",
    "basic:read",
    "dummydata:read",
    "dummydata:update",
    "dummydata:delete"
  ],

  Manager: [
    "manager:read",
    "basic:read",
    "dummydata:read",
    "dummydata:update"
  ],

  User: [
    "basic:read",
    "dummydata:read"
  ],
};

module.exports = (permission) => {
  return (req, res, next) => {
    const permissions = rolePermissions[req.user.role] || [];
    if (!permissions.includes(permission)) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };
};
