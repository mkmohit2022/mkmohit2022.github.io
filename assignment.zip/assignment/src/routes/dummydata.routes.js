const router = require("express").Router();
const DummyData = require("../models/DummyData");
const auth = require("../middleware/auth");
const role = require("../middleware/role");


router.get("/", auth, role("dummydata:read"), async (_, res) => {
  res.json(await DummyData.find());
});


router.put("/:id", auth, role("dummydata:update"), async (req, res) => {
  const updated = await DummyData.findByIdAndUpdate(
    req.params.id,
    req.body,
    { new: true }
  );
  res.json(updated);
});


router.delete("/:id", auth, role("dummydata:delete"), async (req, res) => {
  await DummyData.findByIdAndDelete(req.params.id);
  res.json({ message: "Deleted successfully" });
});

module.exports = router;
