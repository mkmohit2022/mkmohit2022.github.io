const router = require("express").Router();
const auth = require("../middleware/auth");
const role = require("../middleware/role");
const User = require("../models/User");

router.use(auth);

router.get("/users", role("user:read"), async (_, res) => {
  res.json(await User.find());
});

router.put("/users/:id/role", role("user:assign-role"), async (req, res) => {
  res.json(
    await User.findByIdAndUpdate(
      req.params.id,
      { role: req.body.role },
      { new: true }
    )
  );
});


module.exports = router;
