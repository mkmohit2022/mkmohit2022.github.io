This application contains the the backend setup for user registration and role permissions setup for data access and authorization based api endpoints access.

There are three endpoints group
1. auth - it contains the register, login, and forgot passwaords endpoint.
2. admin - few routes for admin which only the authorized admin users can access
3. dummydata - it is a collection having dummy data which users can only view, managers can edit and view and admins can view, edit and delete as well.

All the role handling is done basis the role set in db and fetched via jwt decoding at the api endpoint.

Process to test the application:

1. In the project root library run command: docker compose up --build
this will spin the mongo container for database and the application backend on port 8000.

2. Then run the below api endpoint for first user registration
method: POST
url: http://127.0.0.1:8000/api/auth/register
reqbody: 
{
    "name": "any"
    "email":"test@test.com",
    "password":"any"
}

3. then go to mongo execuatable terminal on docker and run commands

mongosh
use assignment
db.users.updateOne({"email":"test@test.com"},{$set:{"role":"Admin"}})

The above mentioned commands are to set one user as admin for the further endpoints testing.

Now two more users can be created using the register endpoint mentioned above in point 2.

4. User can login to get the access token anytime using the endpoint:
method: POST
url: http://127.0.0.1:8000/api/auth/login
reqbody:
{
  "email": "test@test.com",
  "password": "any"
}
this will return token and user id



NOTE: GOING FORWARD ALL THE ENDPOINTS WILL NEED BEARER TOKEN FROM LOGIN TO ACCESS ANY ENDPOINT

5. Now the admin can see all users by using endpoint
method: GET
url: http://127.0.0.1:8000/api/admin/users

header: Bearer token

6. Admin can change any user permission to manager, admin or user.
method: PUT
url: http://127.0.0.1:8000/api/admin/users/:id/role
reqbody:
{
    "role": "Manager"
}
path parm : user id for whom role to be changed.

7. Forgot password functionality.
firstly the endpoint will get a token and that token can be used to change password

method: POST
url: http://127.0.0.1:8000/api/auth/forgot-password
reqbody: 
{
    "email":"test_manager@test.com"
}

will give token as response can required in next endpoint:

method: POST
url: http://127.0.0.1:8000/api/auth/reset-password/:token
reqbody:
{
    "password": "newpassword"
}
path param: token from previous endpoint


8. NOW to check the role and permissions for the dummy data.

access the url to get data which user, manager and admin can access

method: GET
url: http://127.0.0.1:8000/api/dummydata/

now the edit endpoint which only manager and admin can access

method: PUT
url: http://127.0.0.1:8000/api/dummydata/:id
reqbody:
{
    "title":"new update"
}
path param: id of object

now the delete endpoint which only admins can access

method: DELETE
url: http://127.0.0.1:8000/api/dummydata/:id
path param: id of object


All these above three endpoint can be access using the auth header from login.