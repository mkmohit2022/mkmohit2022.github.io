require("dotenv").config();
const express = require("express");
const connectDB = require("./src/utils/db");
const auth = require("./src/middleware/auth");
const role = require("./src/middleware/role");
const DummyData = require("./src/models/DummyData");

const app = express();


const startServer = async () => {

  await connectDB();
  // Seed DummyData collection (runs only once)
  const count = await DummyData.countDocuments();
  if (count === 0) {
    await DummyData.insertMany([
      {
        title: "check 1",
        description: "this is new data check 1",
        status: "active",
      },
      {
        title: "check 2",
        description: "this is new data check 2",
        status: "active",
      },
    ]);
  }
}

app.use(express.json());

app.use("/api/auth", require("./src/routes/auth.routes"));
app.use("/api/admin", require("./src/routes/admin.routes"));
 app.use("/api/dummydata", require("./src/routes/dummydata.routes"));

app.get("/api/user", auth, role("basic:read"), (_, res) => {
  res.json({ message: "Basic user access" });
});

app.listen(process.env.PORT, () =>
  console.log(`Server running on ${process.env.PORT}`)
);

startServer();